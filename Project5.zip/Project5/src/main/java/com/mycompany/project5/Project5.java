/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project5;
/**
 *
 * @author Big Brace
 */
public class Project5 {

    public static void main(String[] args) {
        String str="*******";
        for (int i=str.length(); i > 0; i--){
            System.out.println(str.substring(0,i));
    }
}  
}   


