/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project2;

/**
 *
 * @author Big Brace
 */
public class Project2 {

    public static void main(String[] args) {
        int x= 70;
        double number1,number2, number3;
        int a= 6;
        int b= 10;
        int c= 15;
                
        double total= a*x;
        double total2= b*x;
        double total3= c*x;
        
        System.out.println("A vehicle traveling a rate of 70mph will travel");
        System.out.println("Distance travled after 6 hours is "+total+" miles");
        System.out.println("Distance travled after 10 hours is "+total2+" miles");
        System.out.println("Distance travled after 15 hours is "+total3+" miles");
                
        
    }
    
}
