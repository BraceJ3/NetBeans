/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project9;

/**
 *
 * @author Big Brace
 */
import java.util.Arrays;
import java.util.Scanner;
public class Project9 {
    public static int SIZE,numStudents;
    public static void main(String[] args) {
       //get number of students
       int numStudents;
       Scanner kb=new Scanner(System.in);
        System.out.println("How many students are in the class?");
        numStudents=kb.nextInt();
       SIZE=numStudents;
       String[] namesArray=new String [SIZE];
       double[] scoresArray=new double[SIZE];
       //fill array
       fillArray(namesArray,scoresArray);
       display(namesArray,scoresArray);
       sort(scoresArray,namesArray);                       
    } 
    public static void sort(double [] scoresArray, String[] namesArray){
      for(int i=0;i<namesArray.length;i++){
        Arrays.sort(scoresArray);
        Arrays.sort(namesArray);
          System.out.println(namesArray[i]);
              
    }
    }
    public static void display(String [] namesArray, double[] scoresArray){
         for(int i=0;i<namesArray.length;i++){            
             System.out.println(namesArray[i]+" has a score of "+scoresArray[i]);
            
             
            }
        }
    
    public static void fillArray(String [] namesArray, double[] scoresArray){
        Scanner kb=new Scanner(System.in);
        // get student details
        for(int i=0;i<namesArray.length;i++){
            System.out.println("Enter the name of student "+(i+1));
            namesArray[i]=kb.nextLine();
            System.out.println("Enter the score of the student "+(i+1));
            scoresArray[i]=Double.parseDouble(kb.nextLine());
            
            
            
            
                }
            }
                
            }
            
        
    

    

    
